﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GDtest
{
    public partial class Form2 : Form
    {
        private Class1 comm;
        private string no;

        public Form2()
        {
            InitializeComponent();
            Load += Form2_Load;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            comm = new Class1(this);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            comm.CUD("sp_insert_GD_borad", false, true, false, "");
            comm.CUD("sp_insert_GD_user", false, false,true, "");
            this.Close();
        }
    }
}

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using GDtest.Module;

namespace GDtest.Controllers
{
    [ApiController]
    public class GDtestController : ControllerBase
    {
        
        [HttpGet]
        public ActionResult<ArrayList> Select()
        {
            Console.WriteLine("select");

            DataBase db = new DataBase();
            SqlDataReader sdr = db.Reader("sp_GD_select");
            ArrayList list = new ArrayList();
            while(sdr.Read())
            {
                string[] arr = new string[4];
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    arr[i] = sdr.GetValue(i).ToString();
                }
                list.Add(arr);
            }
            db.ReaderClose(sdr);

            return list;
        }

        [Route("insert")]
        [HttpPost]
        public ActionResult<string> Insert([FromForm] string Title, [FromForm] string Contents,[FromForm] string Name,[FromForm] string Passod)
        {
            string param = string.Format("{0}, {1}", Title, Contents);
            Console.WriteLine("Insert : " + param);
            Hashtable ht = new Hashtable();
            ht.Add("@name", Title);
            ht.Add("@age", Contents);
            DataBase db = new DataBase();
            if(db.NonQuery("sp_insert_GD_borad", ht))
            {
                return "1";
            }
            else 
            {
                return "0";
            }

            string param1 = string.Format("{0}, {1}", Name, Passod);
            Console.WriteLine("Insert : " + param1);
            Hashtable ht1 = new Hashtable();
            ht.Add("@name", Name);
            ht.Add("@age", Passod);
            if(db.NonQuery("sp_insert_GD_user", ht1))
            {
                return "1";
            }
            else 
            {
                return "0";
            }
        }

        [Route("update")]
        [HttpPost]
        public ActionResult<string> Update([FromForm] string no,[FromForm] string name, [FromForm] string age)
        {
            string param = string.Format("{0}, {1}, {2}", no, name, age);
            Console.WriteLine("Update : " + param);
            Hashtable ht = new Hashtable();
            ht.Add("@no", no);
            ht.Add("@name", name);
            ht.Add("@age", age);
            DataBase db = new DataBase();
            if(db.NonQuery("sp_update", ht))
            {
                return "1";
            }
            else 
            {
                return "0";
            }
        }

        [Route("delete")]
        [HttpPost]
        public ActionResult<string> Delete([FromForm] string no)
        {
            string param = string.Format("{0}", no);
            Console.WriteLine("Delete : " + param);
            Hashtable ht = new Hashtable();
            ht.Add("@no", no);
            DataBase db = new DataBase();
            if(db.NonQuery("sp_delete", ht))
            {
                return "1";
            }
            else 
            {
                return "0";
            }
        }

        [Route("imageUpload")]
        [HttpPost]
        public ActionResult<string> imageUpload([FromForm] string fileName,[FromForm] string fileData)
        {
            Console.WriteLine("fileName : {0}",fileName);
            Console.WriteLine("fileData : {0}",fileData);

            //string path = "D:\\images";
            string path =System.IO.Directory.GetCurrentDirectory(); //GetCurrentDirectory();현제 위치 찾아줌
            path += "\\wwwroot";
            if (!System.IO.Directory.Exists(path))
            {
                System.IO.Directory.CreateDirectory(path);
            }

            byte[] Data = Convert.FromBase64String(fileData);//바이트 변환
            try
            {
                string ext = fileName.Substring(fileName.LastIndexOf("."), fileName.Length - fileName.LastIndexOf("."));
                Guid saveName = Guid.NewGuid();
                string fullName = saveName + ext; //저장되는 파일명 만들기
                string fullpath = string.Format("{0}\\{1}",path,fullName); //전체경로 + 저장파일명 (주소)
                FileInfo fi = new FileInfo(fullpath);
                FileStream fs = fi.Create();
                fs.Write(Data, 0, Data.Length);
                fs.Close();

                string url = string.Format("http://localhost:5000/{0}",fullName);

                Hashtable ht = new Hashtable();
                ht.Add("@fName", fileName);
                ht.Add("@fUrl", url);
                ht.Add("@fDesc", "");
                DataBase db = new DataBase();
                if(db.NonQuery("sp_file_insert", ht))
                {
                    return url;
                }
                else 
                {
                    return "0";
                }
            }
            catch
            {
                Console.WriteLine("파일 저장 중 오류 발생");
            }
            

            
            return fileName;
        }
    }
}

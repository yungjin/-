create table book_info (
 book_number int not null AUTO_INCREMENT,
 title varchar(255) not null,
 author varchar(255) not null,
 publisher varchar(255) not null,
 genre varchar(255) not null,
 brief_introduction nvarchar(4000),
 availability varchar(255) not NULL DEFAULT '가능',
 lender varchar(255) not null DEFAULT 'Non',
 book_location varchar(255)not NULL ,
 image_location	varchar(255),
 image_FileName varchar(255),
 PRIMARY KEY (`book_number`)
);


create table signup(
 user_number int not null AUTO_INCREMENT,
 id varchar(255) not null,
 passwod varchar(255) not null,
 name varchar(255) not null,
 gender varchar(255) not null,
 birthday DATE not null,
 email varchar(255) not null,
 phone_number varchar(255) not null,
 address varchar(255) not null,
 blacklist varchar(255) DEFAULT 'N',
 member_rank INT DEFAULT 1,
 PRIMARY KEY (`user_number`)
);

create table book_rental(
 rental_number int not null AUTO_INCREMENT,
 book_number int not null,
 user_number int not null,
 rental_day DATE not NULL DEFAULT CURRENT_DATE,
 return_schedule DATE not NULL DEFAULT DATE_ADD(Current_date, INTERVAL 14 DAY),
 return_day DATE ,
 rental_status INT NOT NULL DEFAULT 0,
 PRIMARY KEY (`rental_number`),
 CONSTRAINT `FK_book_rental_signup` FOREIGN KEY (`user_number`) REFERENCES `signup` (`user_number`),
 CONSTRAINT `FK_book_rental_book_info` FOREIGN KEY (`book_number`) REFERENCES `book_info` (`book_number`)
);


create table Receiving_equest(
 request_number int not null AUTO_INCREMENT,
 user_number int,
 title varchar(255) not null,
 author varchar(255) not null,
 publisher varchar(255) not null,
 genre varchar(255),
 Request_date DATE DEFAULT CURRENT_DATE,
 PRIMARY KEY (`request_number`),
 CONSTRAINT `FK_Receiving_equest_signup` FOREIGN KEY (`user_number`) REFERENCES `signup` (`user_number`)
);


insert into signup (
id, 
passwod, 
name, 
gender, 
birthday, 
email, 
phone_number, 
address, 
member_rank) 
values (
'root', 
'1234', 
'관리자', 
'성별', 
'2018-12-17', 
'hlc@naver.com', 
'010-0000-0000', 
'서울특별시 금천구 가산동 가산디지털2로', 0);

INSERT INTO signup(
id, 
passwod, 
name, 
gender, 
birthday, 
email,
phone_number,
address) 
VALUES(
'user1', 
'1234', 
'최영진', 
'남', 
'1995-03-18',
'안알랴줌@naver.com',
'010-7616-0880',
'남동구 논고개로 205번길 30-2번지스위트빌 402호');


insert into Receiving_equest (
title, 
author, 
publisher, 
genre, 
user_number) 
values (
"해리포터와 불사조 기사단 2", 
"조앤 K. 롤링", 
"YES24", 
"소설", 1);


INSERT INTO book_info(
title, 
author, 
publisher, 
genre, 
brief_introduction, 
image_location,
book_location ) 
VALUES(
'이것이 C샵이다', 
'박상현', 
'한빛미디어', 
'컴퓨터/IT', 
'한 번 배울 때 제대로, 기본기부터 탄탄히 다지고 간다!
이 책은 C# .NET 프레임워크 세계에 첫 발을 들이는 입문자를 위한 책이다. 따라서 딱딱하지 않은 대화식 표현으로 1:1 강의처럼 배울 수 있는 것이 이 책의 가장 큰 장점이다. 또한 C#의 핵심 문법은 물론, 프로그래밍 동작 원리까지도 입문자 입장에서 하나하나 꼼꼼히 설명하였다. 
책을 덮을 때쯤이면 기초 문법부터, 고급 문법, 그리고 .NET 프레임워크의 활용까지 C#의 전반적인 큰 틀을 자연스레 익힐 수 있을 것이다.
『이것이 C#이다』로 C# 프로그래밍을 시작한다면, 튼튼한 기본기가 갖춰져, 더 이상 실전과 응용도 두렵지 않다! 
',
'http://ljh5432.iptime.org:5000/e3976b00-3b8c-4844-8223-4eed565e0e28.png',
'A-1');


INSERT INTO book_info(
title, 
author, 
publisher, 
genre, 
brief_introduction, 
image_location,
book_location )  
VALUES(
'시작하세요! C샵 7.1프로그래밍', 
'정성태', 
'위키북스', 
'컴퓨터/IT', 
'이 책의 목표는 확실하다. 여러분들이 프로그램을 만들고자 할 때 사용하게 될 프로그래밍 언어인 C#의 기초를 단단하게 다질 수 있도록 이 책을 구성했다. C# 언어를 최신의 7.1 문법까지 설명하고 있으며, 나아가 단순히 언어의 문법 습득에 그치지 않고 실제로 프로그램을 제작할 수 있는 단계까지 학습할 수 있게 내용을 구성했다. ',
'http://ljh5432.iptime.org:5000/be634664-9480-45e8-a22b-571bfc564002.png',
'A-2');

INSERT INTO book_info(
title, 
author, 
publisher, 
genre, 
brief_introduction, 
image_location,
book_location ) 
VALUES(
'ASp.NET&Core를다루는기술.png', 
'박용준',
'길벗', 
'컴퓨터/IT', 
'기술의 집합체인 ASP.NET을 최신 버전 4.6으로 배운다. .NET 기술을 사용하는 오픈 소스이자 크로스플랫폼인 ASP.NET Core 1.0의 새로운 특징도 학습한다. 특히 ASP.NET Core MVC는 Web Pages, Web API, MVC를 하나로 통합하여 관리할 수 있다. 새로운 Web Forms과 MVC 프레임워크를 한 권으로 익혀 보자. ',
'http://ljh5432.iptime.org:5000/398e4654-ffff-42f4-b8e3-600183f8d3b4.png',
'A-3');



INSERT INTO book_rental(
book_number, 
user_number) 
VALUES(
1, 
1);

SELECT * FROM book_info;
SELECT * FROM signup;
SELECT * FROM book_rental;

SELECT CURRENT_DATE;



select	I.title 도서명, I.author 저자, I.publisher 출판사, R.rental_day 대여일, R.return_schedule 반납일,
case	
	when TO_DAYS(now()) - TO_DAYS(R.return_schedule) > 0 then '연체됨'
	when TO_DAYS(now()) - TO_DAYS(R.return_schedule) <= 0 then '연체안됨'
	else ''
end 연체일,
case	
	when R.rental_status = 0 then '대여중'
	when R.rental_status = 1 then '반납요망'
	else ''
end 상태
from	book_info as I
inner join book_rental as R on
(I.book_number = R.book_number);


#!/bin/sh
###############################################################
# Service > systemd > dotnet.service
# Sample Project > /root
# ip Change > 192.168.3."You linux ip"
# MariaDB > user(root)/password(test) > table(test.board)
###############################################################
gitPath=https://github.com/yungjin/test-git.git
rootDir=/root
projectDir=/test-git
publishDir=/test-git/Project/bin/Debug/netcoreapp2.1/publish
serviceDir=/publish
# 1. GitHub Repository Download
cd $rootDir
if [ -d $rootDir$projectDir ]; then
  rm -Rf $rootDir$projectDir
  echo "기존test-git  삭제 "

fi
# 2. Project Build
git clone $gitPath
echo "깃클론( test-git 생성) "

cd $rootDir$projectDir/Project
echo $rootDir$projectDir/Project "위치로 이동 "

dotnet build
echo "닷넷 빌드 "

dotnet publish
echo "퍼블리쉬"

# 3. Service Shutdown
systemctl stop test.service
echo "서비스종료"

# 4. Project Publish
ln -s $rootDir$publishDir $rootDir$serviceDir
echo "링크 생성"

# 5. Service Run
systemctl start test.service
echo "서비스 시작 "


###############################################################

exit 0

